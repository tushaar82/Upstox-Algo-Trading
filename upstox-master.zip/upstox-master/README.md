# Upstox API
A repository of codes that I use with Upstox API for intraday trading!

Upstox provides API access at a price, using which we can ping and get historic price and the current price of all the stocks.
I use this to do intraday trading on market using simple Python scripts.
This repository consists of the codes that I used for the trading.

# Please ALWAYS use this code with your own discretion.
# As in all trading, this involves risk. Do not entirely depend on my codes for making profits as these are not fully tested methods.

I will try to update the codes as and when I get time. There can be a lot of improvisations that can be made to the code. In case you have any improvements suggestions to the code, please contact me and I will be happy to collaborate with you for this project. 
